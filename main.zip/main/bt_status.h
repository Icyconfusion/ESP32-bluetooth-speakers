#pragma once
#include <stdbool.h>

void bt_status_set_connected(bool connected);
bool bt_status_is_connected(void);

void bt_status_set_streaming(bool streaming);
bool bt_status_is_streaming(void);
