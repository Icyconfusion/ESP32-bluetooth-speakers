#include "ui_encoder.h"
#include "controls.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include "esp_log.h"

static const char *TAG = "ui_enc";

// Placeholder pins for now (change later when board arrives)
#define PIN_ENC_A      GPIO_NUM_32
#define PIN_ENC_B      GPIO_NUM_33
#define PIN_ENC_BTN    GPIO_NUM_25

// Queue for encoder events
typedef enum { ENC_EVT_STEP_CW, ENC_EVT_STEP_CCW, ENC_EVT_BTN } enc_evt_t;
static QueueHandle_t s_evt_q;

// Simple quadrature decoder (state table)
static volatile uint8_t s_prev_ab = 0;

static inline uint8_t read_ab(void)
{
    uint8_t a = (gpio_get_level(PIN_ENC_A) ? 1 : 0);
    uint8_t b = (gpio_get_level(PIN_ENC_B) ? 1 : 0);
    return (a << 1) | b;
}

static void IRAM_ATTR isr_enc_ab(void *arg)
{
    // Transition table: prev(2b)<<2 | curr(2b) => delta
    // Valid steps in quadrature produce sequences that yield +/-1 deltas.
    static const int8_t t[16] = {
        0, -1, +1, 0,
        +1, 0, 0, -1,
        -1, 0, 0, +1,
        0, +1, -1, 0
    };

    uint8_t curr = read_ab();
    uint8_t idx = ((s_prev_ab & 0x3) << 2) | (curr & 0x3);
    int8_t delta = t[idx];
    s_prev_ab = curr;

    if (delta != 0) {
        enc_evt_t evt = (delta > 0) ? ENC_EVT_STEP_CW : ENC_EVT_STEP_CCW;
        BaseType_t hp = pdFALSE;
        xQueueSendFromISR(s_evt_q, &evt, &hp);
        if (hp) portYIELD_FROM_ISR();
    }
}

static void IRAM_ATTR isr_enc_btn(void *arg)
{
    // Button to GND with pull-up: pressed == 0
    if (gpio_get_level(PIN_ENC_BTN) == 0) {
        enc_evt_t evt = ENC_EVT_BTN;
        BaseType_t hp = pdFALSE;
        xQueueSendFromISR(s_evt_q, &evt, &hp);
        if (hp) portYIELD_FROM_ISR();
    }
}

static void encoder_task(void *arg)
{
    int vol = controls_get_volume();
    bool muted = controls_is_muted();

    // “detent” smoothing: many encoders generate 2–4 transitions per click.
    // Accumulate steps and apply when magnitude reaches threshold.
    int accum = 0;
    const int steps_per_detent = 2; // adjust later if too sensitive

    while (1) {
        enc_evt_t evt;
        if (xQueueReceive(s_evt_q, &evt, portMAX_DELAY) != pdTRUE) continue;

        if (evt == ENC_EVT_BTN) {
            controls_toggle_mute();
            muted = controls_is_muted();
            ESP_LOGI(TAG, "mute=%d", (int)muted);
            continue;
        }

        accum += (evt == ENC_EVT_STEP_CW) ? 1 : -1;

        if (accum >= steps_per_detent) {
            accum = 0;
            vol += 1;
            controls_set_volume(vol);
            vol = controls_get_volume();
            ESP_LOGI(TAG, "vol=%d", vol);
        } else if (accum <= -steps_per_detent) {
            accum = 0;
            vol -= 1;
            controls_set_volume(vol);
            vol = controls_get_volume();
            ESP_LOGI(TAG, "vol=%d", vol);
        }
    }
}

void ui_encoder_start(void)
{
    s_evt_q = xQueueCreate(32, sizeof(enc_evt_t));
    if (!s_evt_q) {
        ESP_LOGE(TAG, "queue create failed");
        return;
    }

    // A/B inputs with pull-ups
    gpio_config_t ab = {
        .pin_bit_mask = (1ULL << PIN_ENC_A) | (1ULL << PIN_ENC_B),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_ANYEDGE,
    };
    ESP_ERROR_CHECK(gpio_config(&ab));

    // Button input with pull-up
    gpio_config_t btn = {
        .pin_bit_mask = (1ULL << PIN_ENC_BTN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_NEGEDGE, // press only
    };
    ESP_ERROR_CHECK(gpio_config(&btn));

    // Init prev state
    s_prev_ab = read_ab();

    // Install ISR service once (if already installed elsewhere, ignore error)
    esp_err_t e = gpio_install_isr_service(0);
    if (e != ESP_OK && e != ESP_ERR_INVALID_STATE) {
        ESP_ERROR_CHECK(e);
    }

    ESP_ERROR_CHECK(gpio_isr_handler_add(PIN_ENC_A, isr_enc_ab, NULL));
    ESP_ERROR_CHECK(gpio_isr_handler_add(PIN_ENC_B, isr_enc_ab, NULL));
    ESP_ERROR_CHECK(gpio_isr_handler_add(PIN_ENC_BTN, isr_enc_btn, NULL));

    xTaskCreate(encoder_task, "encoder_task", 4096, NULL, 6, NULL);
}
