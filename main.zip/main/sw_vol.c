#include "sw_vol.h"
#include "audio_mem.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include <stdint.h>

static const char *TAG = "sw_vol";

static volatile int  g_vol = 70;     // 0..100
static volatile bool g_mute = false;

void sw_vol_set_volume(int vol_0_100)
{
    if (vol_0_100 < 0) vol_0_100 = 0;
    if (vol_0_100 > 100) vol_0_100 = 100;
    g_vol = vol_0_100;
}

void sw_vol_set_mute(bool mute)
{
    g_mute = mute;
}

static int sw_vol_process(audio_element_handle_t self, char *in_buffer, int in_len)
{
    int rlen = audio_element_input(self, in_buffer, in_len);
    if (rlen <= 0) return rlen;

    int vol = g_mute ? 0 : (int)g_vol;
    int32_t gain_q15 = (int32_t)vol * 32768 / 100;

    int16_t *samples = (int16_t *)in_buffer;
    int sample_count = rlen / 2;

    for (int i = 0; i < sample_count; i++) {
        int32_t s = samples[i];
        s = (s * gain_q15) >> 15;
        if (s > 32767) s = 32767;
        if (s < -32768) s = -32768;
        samples[i] = (int16_t)s;
    }

    return audio_element_output(self, in_buffer, rlen);
}

audio_element_handle_t sw_vol_init(void)
{
    audio_element_cfg_t cfg = DEFAULT_AUDIO_ELEMENT_CONFIG();
    cfg.process = sw_vol_process;
    cfg.buffer_len = 2048;

    audio_element_handle_t el = audio_element_init(&cfg);
    if (!el) {
        ESP_LOGE(TAG, "audio_element_init failed");
        return NULL;
    }
    audio_element_set_tag(el, TAG);
    return el;
}
