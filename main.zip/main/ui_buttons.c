#include "ui_buttons.h"
#include "controls.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"

static const char *TAG = "ui_btn";

// Pick placeholder pins for now (change later when you know your wiring)
#define PIN_BTN_MUTE   GPIO_NUM_27
#define PIN_BTN_EQ     GPIO_NUM_14

static bool read_btn(gpio_num_t pin)
{
    // Using internal pull-up, button to GND => pressed = 0
    return gpio_get_level(pin) == 0;
}

static void buttons_task(void *arg)
{
    bool prev_mute = false;
    bool prev_eq   = false;

    while (1) {
        bool mute_now = read_btn(PIN_BTN_MUTE);
        bool eq_now   = read_btn(PIN_BTN_EQ);

        // rising edge (not pressed -> pressed)
        if (!prev_mute && mute_now) {
            controls_toggle_mute();
            ESP_LOGI(TAG, "mute toggled");
        }

        if (!prev_eq && eq_now) {
            eq_preset_t p = controls_get_eq_preset();
            p = (eq_preset_t)((p + 1) % EQ_PRESET_COUNT);
            controls_set_eq_preset(p);
            ESP_LOGI(TAG, "eq preset = %d", (int)p);
        }

        prev_mute = mute_now;
        prev_eq   = eq_now;

        vTaskDelay(pdMS_TO_TICKS(25)); // debounce-ish polling
    }
}

void ui_buttons_start(void)
{
    gpio_config_t io = {
        .pin_bit_mask = (1ULL << PIN_BTN_MUTE) | (1ULL << PIN_BTN_EQ),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&io));

    xTaskCreate(buttons_task, "buttons_task", 3072, NULL, 5, NULL);
}
