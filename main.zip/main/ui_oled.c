#include "ui_oled.h"
#include "controls.h"
#include "board_pins.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include <string.h>
#include <stdio.h>
#include <stdint.h>

#include "bt_status.h" // including the bluetooth status function for the oled

static const char *TAG = "ui_oled";

// ---- Config (override these in your board_pins.h if you already have them) ----
#ifndef OLED_I2C_PORT
#define OLED_I2C_PORT I2C_NUM_0
#endif

#ifndef OLED_SDA_PIN
#define OLED_SDA_PIN 21
#endif

#ifndef OLED_SCL_PIN
#define OLED_SCL_PIN 22
#endif

#ifndef OLED_ADDR
#define OLED_ADDR 0x3C
#endif

// SSD1306 commands
#define CMD 0x00
#define DAT 0x40

static uint8_t fb[128 * 64 / 8]; // 1024 bytes



// Minimal glyph helpers (so we can print numbers + a few words)
static void draw_char(int x, int y, char c)
{
    // Very small minimal renderer: digits, letters A-Z, '-', ':', '%', and space
    // If char unsupported, render blank
    const uint8_t *glyph = NULL;
    static uint8_t g[5];

    memset(g, 0, sizeof(g));

    if (c >= '0' && c <= '9') {
        // crude 5x7 digits
        static const uint8_t digits[10][5] = {
            {0x3E,0x51,0x49,0x45,0x3E}, //0
            {0x00,0x42,0x7F,0x40,0x00}, //1
            {0x42,0x61,0x51,0x49,0x46}, //2
            {0x21,0x41,0x45,0x4B,0x31}, //3
            {0x18,0x14,0x12,0x7F,0x10}, //4
            {0x27,0x45,0x45,0x45,0x39}, //5
            {0x3C,0x4A,0x49,0x49,0x30}, //6
            {0x01,0x71,0x09,0x05,0x03}, //7
            {0x36,0x49,0x49,0x49,0x36}, //8
            {0x06,0x49,0x49,0x29,0x1E}, //9
        };
        glyph = digits[c - '0'];
    } else if (c >= 'A' && c <= 'Z') {
        static const uint8_t alpha[26][5] = {
            {0x7E,0x11,0x11,0x11,0x7E}, //A
            {0x7F,0x49,0x49,0x49,0x36}, //B
            {0x3E,0x41,0x41,0x41,0x22}, //C
            {0x7F,0x41,0x41,0x22,0x1C}, //D
            {0x7F,0x49,0x49,0x49,0x41}, //E
            {0x7F,0x09,0x09,0x09,0x01}, //F
            {0x3E,0x41,0x49,0x49,0x7A}, //G
            {0x7F,0x08,0x08,0x08,0x7F}, //H
            {0x00,0x41,0x7F,0x41,0x00}, //I
            {0x20,0x40,0x41,0x3F,0x01}, //J
            {0x7F,0x08,0x14,0x22,0x41}, //K
            {0x7F,0x40,0x40,0x40,0x40}, //L
            {0x7F,0x02,0x0C,0x02,0x7F}, //M
            {0x7F,0x04,0x08,0x10,0x7F}, //N
            {0x3E,0x41,0x41,0x41,0x3E}, //O
            {0x7F,0x09,0x09,0x09,0x06}, //P
            {0x3E,0x41,0x51,0x21,0x5E}, //Q
            {0x7F,0x09,0x19,0x29,0x46}, //R
            {0x46,0x49,0x49,0x49,0x31}, //S
            {0x01,0x01,0x7F,0x01,0x01}, //T
            {0x3F,0x40,0x40,0x40,0x3F}, //U
            {0x1F,0x20,0x40,0x20,0x1F}, //V
            {0x3F,0x40,0x38,0x40,0x3F}, //W
            {0x63,0x14,0x08,0x14,0x63}, //X
            {0x07,0x08,0x70,0x08,0x07}, //Y
            {0x61,0x51,0x49,0x45,0x43}, //Z
        };
        glyph = alpha[c - 'A'];
    } else if (c == '-') {
        static const uint8_t dash[5] = {0x08,0x08,0x08,0x08,0x08};
        glyph = dash;
    } else if (c == ':') {
        static const uint8_t colon[5] = {0x00,0x36,0x36,0x00,0x00};
        glyph = colon;
    } else if (c == '%') {
        static const uint8_t pct[5] = {0x62,0x64,0x08,0x13,0x23};
        glyph = pct;
    } else if (c == ' ') {
        static const uint8_t sp[5] = {0,0,0,0,0};
        glyph = sp;
    } else {
        static const uint8_t blank[5] = {0,0,0,0,0};
        glyph = blank;
    }

    // Draw into framebuffer (page-based: y in pixels)
    for (int col = 0; col < 5; col++) {
        uint8_t bits = glyph[col];
        for (int row = 0; row < 8; row++) {
            int px = x + col;
            int py = y + row;
            if (px < 0 || px >= 128 || py < 0 || py >= 64) continue;
            int idx = px + (py / 8) * 128;
            uint8_t mask = 1 << (py % 8);
            if (bits & (1 << row)) fb[idx] |= mask;
            else fb[idx] &= ~mask;
        }
    }
}

static void draw_text(int x, int y, const char *s)
{
    while (*s) {
        draw_char(x, y, *s++);
        x += 6; // 5px + 1 space
        if (x > 122) break;
    }
}

static esp_err_t oled_write_cmd(uint8_t cmd)
{
    uint8_t buf[2] = {CMD, cmd};
    return i2c_master_write_to_device(OLED_I2C_PORT, OLED_ADDR, buf, sizeof(buf), pdMS_TO_TICKS(100));
}

static esp_err_t oled_init(void)
{
    // I2C init
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = OLED_SDA_PIN,
        .scl_io_num = OLED_SCL_PIN,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 400000,
    };
    ESP_ERROR_CHECK(i2c_param_config(OLED_I2C_PORT, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(OLED_I2C_PORT, conf.mode, 0, 0, 0));

    vTaskDelay(pdMS_TO_TICKS(50));

    // SSD1306 init sequence (common)
    ESP_ERROR_CHECK(oled_write_cmd(0xAE)); // display off
    ESP_ERROR_CHECK(oled_write_cmd(0x20)); ESP_ERROR_CHECK(oled_write_cmd(0x00)); // horizontal addressing
    ESP_ERROR_CHECK(oled_write_cmd(0xB0)); // page 0
    ESP_ERROR_CHECK(oled_write_cmd(0xC8)); // COM scan dec
    ESP_ERROR_CHECK(oled_write_cmd(0x00)); // low column
    ESP_ERROR_CHECK(oled_write_cmd(0x10)); // high column
    ESP_ERROR_CHECK(oled_write_cmd(0x40)); // start line
    ESP_ERROR_CHECK(oled_write_cmd(0x81)); ESP_ERROR_CHECK(oled_write_cmd(0x7F)); // contrast
    ESP_ERROR_CHECK(oled_write_cmd(0xA1)); // seg remap
    ESP_ERROR_CHECK(oled_write_cmd(0xA6)); // normal
    ESP_ERROR_CHECK(oled_write_cmd(0xA8)); ESP_ERROR_CHECK(oled_write_cmd(0x3F)); // multiplex 1/64
    ESP_ERROR_CHECK(oled_write_cmd(0xA4)); // output follows RAM
    ESP_ERROR_CHECK(oled_write_cmd(0xD3)); ESP_ERROR_CHECK(oled_write_cmd(0x00)); // display offset
    ESP_ERROR_CHECK(oled_write_cmd(0xD5)); ESP_ERROR_CHECK(oled_write_cmd(0x80)); // clk
    ESP_ERROR_CHECK(oled_write_cmd(0xD9)); ESP_ERROR_CHECK(oled_write_cmd(0xF1)); // precharge
    ESP_ERROR_CHECK(oled_write_cmd(0xDA)); ESP_ERROR_CHECK(oled_write_cmd(0x12)); // com pins
    ESP_ERROR_CHECK(oled_write_cmd(0xDB)); ESP_ERROR_CHECK(oled_write_cmd(0x40)); // vcomh
    ESP_ERROR_CHECK(oled_write_cmd(0x8D)); ESP_ERROR_CHECK(oled_write_cmd(0x14)); // charge pump
    ESP_ERROR_CHECK(oled_write_cmd(0xAF)); // display on
    return ESP_OK;
}

static esp_err_t oled_flush(void)
{
    // Set address window
    ESP_ERROR_CHECK(oled_write_cmd(0x21)); ESP_ERROR_CHECK(oled_write_cmd(0)); ESP_ERROR_CHECK(oled_write_cmd(127));
    ESP_ERROR_CHECK(oled_write_cmd(0x22)); ESP_ERROR_CHECK(oled_write_cmd(0)); ESP_ERROR_CHECK(oled_write_cmd(7));

    // Send framebuffer in chunks
    uint8_t chunk[1 + 16];
    chunk[0] = DAT;

    for (int i = 0; i < (int)sizeof(fb); i += 16) {
        memcpy(&chunk[1], &fb[i], 16);
        ESP_ERROR_CHECK(i2c_master_write_to_device(OLED_I2C_PORT, OLED_ADDR, chunk, sizeof(chunk), pdMS_TO_TICKS(100)));
    }
    return ESP_OK;
}

static const char *preset_name(eq_preset_t p)
{
    switch (p) {
        case EQ_FLAT:   return "FLAT";
        case EQ_BASS:   return "BASS";
        case EQ_VOCAL:  return "VOCAL";
        case EQ_ROCK:   return "ROCK";
        case EQ_TREBLE: return "TREBLE";
        default:        return "UNK";
    }
}

static void oled_task(void *arg)
{
    if (oled_init() != ESP_OK) {
        ESP_LOGE(TAG, "oled init failed");
        vTaskDelete(NULL);
        return;
    }

    while (1) {
        memset(fb, 0, sizeof(fb));
 int vol = controls_get_volume();
        bool muted = controls_is_muted();
        eq_preset_t p = controls_get_eq_preset();

        bool c = bt_status_is_connected();
        bool s = bt_status_is_streaming();

        char line1[32], line2[32], line3[32], line4[32];
        snprintf(line1, sizeof(line1), "VOL:%d%%", vol);
        snprintf(line2, sizeof(line2), "MUTE:%s", muted ? "ON" : "OFF");
        snprintf(line3, sizeof(line3), "EQ:%s", preset_name(p));
        snprintf(line4, sizeof(line4), "BT:%s", s ? "STREAM" : (c ? "CONN" : "PAIR"));

        draw_text(0, 0,  line1);
        draw_text(0, 16, line2);
        draw_text(0, 32, line3);
        draw_text(0, 48, line4);

        oled_flush();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void ui_oled_start(void)
{
    xTaskCreate(oled_task, "oled_task", 4096, NULL, 5, NULL);
}
