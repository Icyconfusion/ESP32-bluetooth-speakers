#include "controls.h"
#include "sw_vol.h"
#include "esp_log.h"
#include "equalizer.h"

static const char *TAG = "controls";

// These are your global handles in play_bt_music_example.c
extern audio_element_handle_t g_eq;

static int g_volume = 70;
static bool g_muted = false;
static eq_preset_t g_preset = EQ_FLAT;

static void apply_volume(void)
{
    sw_vol_set_mute(g_muted);
    sw_vol_set_volume(g_volume);
}

static void apply_eq(void)
{
    if (!g_eq) return;

    // 10-band indices (0..9) for this equalizer implementation
    // Values are gain steps; start conservative.
    static const int presets[EQ_PRESET_COUNT][10] = {
        // FLAT
        {0,0,0,0,0,0,0,0,0,0},
        // BASS
        {6,5,4,2,0,0,0,-1,-2,-3},
        // VOCAL (push mids)
        {-2,-1,0,2,4,4,2,0,-1,-2},
        // ROCK (smile)
        {4,3,2,0,-1,-1,0,2,3,4},
        // TREBLE
        {-3,-2,-1,0,0,1,2,4,5,6},
    };

    for (int i = 0; i < 10; i++) {
        equalizer_set_gain_info(g_eq, i, presets[g_preset][i], true);
    }
}

void controls_init(void)
{
    apply_volume();
    apply_eq();
    ESP_LOGI(TAG, "controls init: vol=%d mute=%d preset=%d", g_volume, (int)g_muted, (int)g_preset);
}

void controls_set_volume(int vol)
{
    if (vol < 0) vol = 0;
    if (vol > 100) vol = 100;
    g_volume = vol;
    apply_volume();
}

int controls_get_volume(void) { return g_volume; }

void controls_toggle_mute(void)
{
    g_muted = !g_muted;
    apply_volume();
}

bool controls_is_muted(void) { return g_muted; }

void controls_set_eq_preset(eq_preset_t p)
{
    if (p < 0) p = 0;
    if (p >= EQ_PRESET_COUNT) p = EQ_PRESET_COUNT - 1;
    g_preset = p;
    apply_eq();
}

eq_preset_t controls_get_eq_preset(void) { return g_preset; }
