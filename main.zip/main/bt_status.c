#include "bt_status.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static bool s_connected = false;
static bool s_streaming = false;
static SemaphoreHandle_t s_lock;

static void ensure_lock(void)
{
    if (!s_lock) s_lock = xSemaphoreCreateMutex();
}

void bt_status_set_connected(bool connected)
{
    ensure_lock();
    xSemaphoreTake(s_lock, portMAX_DELAY);
    s_connected = connected;
    xSemaphoreGive(s_lock);
}

bool bt_status_is_connected(void)
{
    ensure_lock();
    xSemaphoreTake(s_lock, portMAX_DELAY);
    bool v = s_connected;
    xSemaphoreGive(s_lock);
    return v;
}

void bt_status_set_streaming(bool streaming)
{
    ensure_lock();
    xSemaphoreTake(s_lock, portMAX_DELAY);
    s_streaming = streaming;
    xSemaphoreGive(s_lock);
}

bool bt_status_is_streaming(void)
{
    ensure_lock();
    xSemaphoreTake(s_lock, portMAX_DELAY);
    bool v = s_streaming;
    xSemaphoreGive(s_lock);
    return v;
}
