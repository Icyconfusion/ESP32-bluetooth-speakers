#pragma once
#include <stdbool.h>

void controls_init(void);

// volume 0..100
void controls_set_volume(int vol);
int  controls_get_volume(void);

void controls_toggle_mute(void);
bool controls_is_muted(void);

// EQ presets
typedef enum {
    EQ_FLAT = 0,
    EQ_BASS,
    EQ_VOCAL,
    EQ_ROCK,
    EQ_TREBLE,
    EQ_PRESET_COUNT
} eq_preset_t;

void controls_set_eq_preset(eq_preset_t p);
eq_preset_t controls_get_eq_preset(void);
