#pragma once

// ---- I2S to PCM5102 ----
#define PIN_I2S_BCK   26
#define PIN_I2S_WS    25
#define PIN_I2S_DOUT  27
// PCM5102 SCK/MCLK not used

// ---- I2C OLED (SSD1306) ----
#define PIN_I2C_SDA   21
#define PIN_I2C_SCL   22

// ---- Encoder ----
#define PIN_ENC_A     34
#define PIN_ENC_B     35
#define PIN_ENC_SW    33

// ---- Buttons ----
#define PIN_BTN_EQ    12
#define PIN_BTN_MUTE  13
#define PIN_BTN_PLAY  14
