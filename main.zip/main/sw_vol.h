#pragma once
#include <stdbool.h>
#include "audio_element.h"

audio_element_handle_t sw_vol_init(void);
void sw_vol_set_volume(int vol_0_100);   // 0..100
void sw_vol_set_mute(bool mute);
